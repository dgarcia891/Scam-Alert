import { MessageTypes } from '../lib/messaging.js';

console.log('[Scam Alert] Content script loaded');

const OVERLAY_ID = 'scam-alert-overlay-root';

function createOverlay(result) {
    // Remove existing if any
    const existing = document.getElementById(OVERLAY_ID);
    if (existing) existing.remove();

    // Create container
    const container = document.createElement('div');
    container.id = OVERLAY_ID;

    // Create Shadow DOM to isolate styles
    const shadow = container.attachShadow({ mode: 'open' });

    // Inject styles
    const style = document.createElement('style');
    style.textContent = `
        :host {
            all: initial;
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            background: linear-gradient(135deg, #7f1d1d 0%, #450a0a 100%);
            z-index: 2147483647; /* Max Z-Index */
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: system-ui, -apple-system, sans-serif;
            color: white;
            backdrop-filter: blur(10px);
        }
        .card {
            background: rgba(0, 0, 0, 0.4);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            padding: 3rem;
            border-radius: 1.5rem;
            max-width: 600px;
            text-align: center;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
            animation: fadeIn 0.3s ease-out;
        }
        h1 {
            font-size: 2.5rem;
            font-weight: 800;
            margin: 0 0 1rem 0;
            color: #fca5a5;
        }
        p {
            font-size: 1.125rem;
            line-height: 1.6;
            color: #e5e7eb;
            margin-bottom: 2rem;
        }
        .recommendation {
            background: rgba(220, 38, 38, 0.2);
            border: 1px solid #dc2626;
            padding: 1rem;
            border-radius: 0.5rem;
            margin-bottom: 2rem;
            font-weight: 500;
        }
        .actions {
            display: flex;
            gap: 1rem;
            justify-content: center;
            flex-direction: column;
        }
        button.primary {
            background: #ef4444;
            color: white;
            border: none;
            padding: 1rem 2rem;
            font-size: 1.125rem;
            font-weight: 600;
            border-radius: 0.75rem;
            cursor: pointer;
            transition: transform 0.1s, background 0.2s;
        }
        button.primary:hover {
            background: #dc2626;
            transform: scale(1.02);
        }
        button.secondary {
            background: transparent;
            border: none;
            color: #9ca3af;
            text-decoration: underline;
            cursor: pointer;
            font-size: 0.875rem;
            margin-top: 1rem;
        }
        button.secondary:hover {
            color: white;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: scale(0.95); }
            to { opacity: 1; transform: scale(1); }
        }
    `;
    shadow.appendChild(style);

    // Content
    const wrapper = document.createElement('div');
    wrapper.className = 'card';

    wrapper.innerHTML = `
        <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="#fca5a5" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-bottom: 1.5rem;">
            <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
            <line x1="12" y1="9" x2="12" y2="13"></line>
            <line x1="12" y1="17" x2="12.01" y2="17"></line>
        </svg>
        <h1>Deceptive Site Ahead</h1>
        <p>Scam Alert has blocked this page because it matches known scam patterns or phishing techniques.</p>
        
        <div class="recommendation">
            Reason: <strong>${result?.recommendations?.[0] || 'Suspicious Activity Detected'}</strong>
        </div>

        <div class="actions">
            <button class="primary" id="btn-back">Get Me Out of Here</button>
            <button class="secondary" id="btn-proceed">I understand the risks, proceed anyway</button>
        </div>
    `;

    shadow.appendChild(wrapper);

    // Handlers
    const btnBack = shadow.getElementById('btn-back');
    const btnProceed = shadow.getElementById('btn-proceed');

    btnBack.addEventListener('click', () => {
        window.history.back();
        // Fallback if no history
        setTimeout(() => window.close(), 500);
    });

    btnProceed.addEventListener('click', () => {
        container.remove();
        // Ideally we'd whitelist this session, but for now just removing the overlay is enough
    });

    document.documentElement.appendChild(container);
}

// Listen for messages
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    function showDetectionToast(result) {
        const existing = document.getElementById('scam-alert-toast');
        if (existing) existing.remove();

        const toast = document.createElement('div');
        toast.id = 'scam-alert-toast';
        toast.style.cssText = `
            position: fixed;
            top: 24px;
            right: 24px;
            z-index: 999999;
            background: #0f172a;
            border: 1px solid ${result.overallSeverity === 'HIGH' ? '#e11d4866' : '#f59e0b66'};
            border-left: 4px solid ${result.overallSeverity === 'HIGH' ? '#e11d48' : '#f59e0b'};
            padding: 16px 20px;
            border-radius: 12px;
            box-shadow: 0 20px 25px -5px rgb(0 0 0 / 0.5);
            display: flex;
            align-items: center;
            gap: 16px;
            color: white;
            font-family: sans-serif;
            max-width: 350px;
        `;

        const iconColor = result.overallSeverity === 'HIGH' ? '#e11d48' : '#f59e0b';
        toast.innerHTML = `
            <div style="background: ${iconColor}22; padding: 8px; border-radius: 8px;">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="${iconColor}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m12 19 9 2-9-18-9 18 9-2zm0 0v-8"/></svg>
            </div>
            <div style="flex: 1;">
                <div style="font-weight: 700; font-size: 14px;">${result.overallSeverity} Risk Detected</div>
                <div style="font-size: 12px; color: #94a3b8;">${result.summary || 'Suspicious activity found.'}</div>
            </div>
        `;
        document.body.appendChild(toast);
        setTimeout(() => toast.remove(), 6000);
    }

    if (message.type === MessageTypes.SHOW_WARNING) {
        console.warn('[Scam Alert] Received warning command', message.data);
        createOverlay(message.data.result);
        sendResponse({ success: true });
    } else if (message.type === MessageTypes.SCAN_RESULT && message.data?.result) {
        showDetectionToast(message.data.result);
        sendResponse({ success: true });
    }
});
