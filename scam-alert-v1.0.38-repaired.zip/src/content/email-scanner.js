import { MessageTypes } from '../lib/messaging.js';

(function () {
    let currentEmailId = null;
    let scanThrottleTimeout = null;

    const SELECTORS = {
        GMAIL: {
            container: '.nH.hx',
            messageBody: '.a3s.aiL, .ii.gt, [role="gridcell"] .a3s', // Expanded selectors
            sender: '.gD, .ov.adx',
            subject: '.hP'
        },
        OUTLOOK: {
            container: '[role="main"]',
            messageBody: '.rps_2003, .rps_2016, [aria-label="Message body"], .BodyFragment',
            sender: '[data-contact-info]',
            subject: '[role="heading"][aria-level="2"]'
        }
    };

    async function getEmailSettings() {
        return new Promise((resolve) => {
            chrome.storage.local.get(['settings'], (result) => {
                const settings = result.settings || {};
                resolve({
                    enabled: settings.emailScanningEnabled !== false,
                    promptDisabled: settings.emailPromptDisabled === true
                });
            });
        });
    }

    /**
     * Check if should show the activation prompt
     */
    async function shouldShowPrompt(settings) {
        if (settings.enabled || settings.promptDisabled) return false;

        // Check session storage for "Remind Me Later"
        return new Promise((resolve) => {
            try {
                // We use local storage for "dismissed this session" with a prefix if session access isn't enabled
                chrome.storage.local.get(['emailPromptSessionDismissed'], (result) => {
                    resolve(!result.emailPromptSessionDismissed);
                });
            } catch {
                resolve(true);
            }
        });
    }

    /**
     * Create and show the activation prompt
     */
    function showActivationPrompt() {
        const PROMPT_ID = 'scam-alert-activation-prompt';
        if (document.getElementById(PROMPT_ID)) return;

        const container = document.createElement('div');
        container.id = PROMPT_ID;
        const shadow = container.attachShadow({ mode: 'open' });

        const style = document.createElement('style');
        style.textContent = `
            :host {
                position: fixed;
                bottom: 24px;
                right: 24px;
                z-index: 2147483647;
                font-family: system-ui, -apple-system, sans-serif;
            }
            .card {
                background: #1e293b;
                color: #f8fafc;
                padding: 24px;
                border-radius: 16px;
                width: 340px;
                box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.5), 0 10px 10px -5px rgba(0, 0, 0, 0.4);
                border: 1px solid #334155;
                animation: slideUp 0.4s cubic-bezier(0.16, 1, 0.3, 1);
            }
            @keyframes slideUp {
                from { transform: translateY(100px); opacity: 0; }
                to { transform: translateY(0); opacity: 1; }
            }
            .header {
                display: flex;
                align-items: center;
                gap: 12px;
                margin-bottom: 12px;
            }
            .icon {
                background: rgba(99, 102, 241, 0.1);
                color: #818cf8;
                padding: 8px;
                border-radius: 10px;
            }
            .title {
                font-weight: 700;
                font-size: 16px;
                color: #f1f5f9;
            }
            .message {
                font-size: 13px;
                line-height: 1.5;
                color: #94a3b8;
                margin-bottom: 20px;
            }
            .actions {
                display: flex;
                flex-direction: column;
                gap: 8px;
            }
            button {
                padding: 10px 16px;
                font-size: 13px;
                font-weight: 600;
                border-radius: 8px;
                cursor: pointer;
                transition: all 0.2s;
                border: none;
                text-align: center;
            }
            .btn-primary {
                background: #6366f1;
                color: white;
            }
            .btn-primary:hover { background: #4f46e5; }
            .btn-secondary {
                background: #334155;
                color: #cbd5e1;
            }
            .btn-secondary:hover { background: #475569; color: white; }
            .btn-ghost {
                background: transparent;
                color: #64748b;
                font-size: 12px;
                margin-top: 4px;
            }
            .btn-ghost:hover { color: #94a3b8; text-decoration: underline; }
        `;
        shadow.appendChild(style);

        const card = document.createElement('div');
        card.className = 'card';
        card.innerHTML = `
            <div class="header">
                <div class="icon">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                </div>
                <div class="title">Email Protection Off</div>
            </div>
            <div class="message">
                Real-time scanning for phishing and gift card scams is currently disabled. Would you like to turn it on for your safety?
            </div>
            <div class="actions">
                <button class="btn-primary" id="btn-on">Turn On Protection</button>
                <button class="btn-secondary" id="btn-later">Remind Me Later</button>
                <button class="btn-ghost" id="btn-never">Never ask me again</button>
            </div>
        `;

        shadow.appendChild(card);

        // Handlers
        shadow.getElementById('btn-on').onclick = async () => {
            chrome.storage.local.get(['settings'], (result) => {
                const settings = result.settings || {};
                settings.emailScanningEnabled = true;
                chrome.storage.local.set({ settings }, () => {
                    container.remove();
                    triggerScan(); // Immediate scan
                });
            });
        };

        shadow.getElementById('btn-later').onclick = () => {
            // Dismiss for current browser session (simulated via local storage with volatile flag)
            chrome.storage.local.set({ emailPromptSessionDismissed: true }, () => {
                container.remove();
            });
        };

        shadow.getElementById('btn-never').onclick = () => {
            chrome.storage.local.get(['settings'], (result) => {
                const settings = result.settings || {};
                settings.emailPromptDisabled = true;
                chrome.storage.local.set({ settings }, () => {
                    container.remove();
                });
            });
        };

        document.body.appendChild(container);
    }

    /**
     * Extract email data from the DOM
     */
    function extractEmailData() {
        const isGmail = window.location.hostname.includes('mail.google.com');
        const isOutlook = window.location.hostname.includes('outlook') || window.location.hostname.includes('office.com');

        let bodyText = '';
        let senderName = '';
        let senderEmail = '';
        let subject = '';

        if (isGmail) {
            const body = document.querySelector(SELECTORS.GMAIL.messageBody);
            const sender = document.querySelector(SELECTORS.GMAIL.sender);
            const subj = document.querySelector(SELECTORS.GMAIL.subject);

            if (body) bodyText = body.innerText;
            if (sender) {
                senderName = sender.getAttribute('name') || sender.innerText;
                senderEmail = sender.getAttribute('email');
            }
            if (subj) subject = subj.innerText;
        } else if (isOutlook) {
            const body = document.querySelector(SELECTORS.OUTLOOK.messageBody);
            const sender = document.querySelector(SELECTORS.OUTLOOK.sender);
            const subj = document.querySelector(SELECTORS.OUTLOOK.subject);

            if (body) bodyText = body.innerText;
            if (sender) {
                senderName = sender.innerText;
                // Outlook often hides email in attributes
                senderEmail = sender.getAttribute('data-contact-info') || '';
            }
            if (subj) subject = subj.innerText;
        }

        return { bodyText, senderName, senderEmail, subject, isEmailView: true };
    }

    /**
     * Trigger a scan of the current email
     */
    async function triggerScan() {
        const settings = await getEmailSettings();

        if (!settings.enabled) {
            if (await shouldShowPrompt(settings)) {
                showActivationPrompt();
            }
            return;
        }

        const data = extractEmailData();
        if (!data.bodyText) return;

        // Generate a simple ID to avoid re-scanning the same email immediately (Safe from non-Latin1)
        const contentId = `${data.senderEmail || 'anon'}_${data.bodyText.substring(0, 100)}`;
        if (contentId === currentEmailId) return;
        currentEmailId = contentId;

        console.log('[Scam Alert] Scanning email message...');

        chrome.runtime.sendMessage({
            type: MessageTypes.SCAN_CURRENT_TAB,
            data: {
                forceRefresh: true,
                pageContent: data // Send content directly to bypass tab-parsing in background
            }
        });
    }

    /**
     * Observe DOM changes to detect when an email is opened
     */
    const observer = new MutationObserver(() => {
        if (scanThrottleTimeout) return;

        scanThrottleTimeout = setTimeout(() => {
            triggerScan();
            scanThrottleTimeout = null;
        }, 1000); // 1s throttle
    });

    // Start observing
    const targetNode = document.body;
    const config = { childList: true, subtree: true };
    observer.observe(targetNode, config);

    /**
     * Highlights matching phrases directly in the email body
     */
    function applyInPageHighlighting(result) {
        const matches = [];
        if (result.checks) {
            Object.values(result.checks).forEach(check => {
                if (check.matches) matches.push(...check.matches);
            });
        }

        if (matches.length === 0) return;

        const isGmail = window.location.hostname.includes('mail.google.com');
        const selector = isGmail ? SELECTORS.GMAIL.messageBody : SELECTORS.OUTLOOK.messageBody;
        const container = document.querySelector(selector);

        if (!container) return;

        // Use TreeWalker to find text nodes (safest way to modify DOM without breaking event listeners)
        const walker = document.createTreeWalker(container, NodeFilter.SHOW_TEXT, null, false);
        const nodes = [];
        let node;
        while (node = walker.nextNode()) {
            if (node.parentNode.closest('.scam-alert-highlight')) continue;
            nodes.push(node);
        }

        const sortedMatches = [...new Set(matches.filter(Boolean))].sort((a, b) => b.length - a.length);
        const regexStr = sortedMatches.map(m => m.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|');
        if (!regexStr) return;

        const regex = new RegExp(`(${regexStr})`, 'gi');

        nodes.forEach(textNode => {
            const content = textNode.nodeValue;
            regex.lastIndex = 0; // Reset before test
            if (regex.test(content)) {
                regex.lastIndex = 0; // Reset for replace
                const fragment = document.createDocumentFragment();
                let lastIndex = 0;

                // Use replace with function to iterate through all matches in this node
                content.replace(regex, (match, p1, offset) => {
                    fragment.appendChild(document.createTextNode(content.substring(lastIndex, offset)));
                    const highlight = document.createElement('mark');
                    const severityClass = result.overallSeverity === 'CRITICAL' || result.overallSeverity === 'HIGH'
                        ? ' scam-alert-highlight-critical'
                        : '';
                    highlight.className = 'scam-alert-highlight' + severityClass;
                    highlight.textContent = match;
                    fragment.appendChild(highlight);
                    lastIndex = offset + match.length;
                    return match;
                });

                fragment.appendChild(document.createTextNode(content.substring(lastIndex)));
                textNode.parentNode.replaceChild(fragment, textNode);
            }
        });
    }

    function showThreatDashboard(result) {
        const DASHBOARD_ID = 'scam-alert-threat-dashboard';
        const existing = document.getElementById(DASHBOARD_ID);
        if (existing) existing.remove();

        // Create a wrapper for backdrop
        const container = document.createElement('div');
        container.id = DASHBOARD_ID;
        const shadow = container.attachShadow({ mode: 'open' });

        const isCritical = result.overallSeverity === 'CRITICAL' || result.overallSeverity === 'HIGH';
        const accentColor = isCritical ? '#e11d48' : '#f59e0b';
        const accentBg = isCritical ? 'rgba(225, 29, 72, 0.15)' : 'rgba(245, 158, 11, 0.15)';

        const style = document.createElement('style');
        style.textContent = `
            :host {
                position: fixed;
                top: 0;
                left: 0;
                width: 100vw;
                height: 100vh;
                pointer-events: none;
                z-index: 2147483647;
                display: flex;
                align-items: flex-start;
                justify-content: flex-end;
                padding: 24px;
                box-sizing: border-box;
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            }
            .sa-backdrop {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, 0.3);
                backdrop-filter: blur(2px);
                pointer-events: auto;
                animation: sa-fade-in 0.4s ease-out;
            }
            @keyframes sa-fade-in {
                from { opacity: 0; }
                to { opacity: 1; }
            }
            .sa-card {
                position: relative;
                pointer-events: auto;
                background: #0f172a;
                color: #f8fafc;
                width: 380px;
                border-radius: 24px;
                box-shadow: 0 0 0 1px ${accentColor}44, 0 25px 50px -12px rgba(0, 0, 0, 0.8), 0 0 30px ${accentColor}22;
                border: 1px solid ${accentColor}66;
                border-top: 6px solid ${accentColor};
                overflow: hidden;
                animation: sa-slide-in 0.5s cubic-bezier(0.16, 1, 0.3, 1);
            }
            @keyframes sa-slide-in {
                from { transform: translateX(500px) scale(0.9); opacity: 0; }
                to { transform: translateX(0) scale(1); opacity: 1; }
            }
            .sa-header {
                padding: 20px 24px;
                background: linear-gradient(to bottom, ${accentBg}, transparent);
                display: flex;
                align-items: center;
                justify-content: space-between;
                border-bottom: 1px solid #1e293b;
            }
            .sa-title {
                display: flex;
                align-items: center;
                gap: 12px;
                font-weight: 900;
                font-size: 16px;
                letter-spacing: -0.02em;
                color: ${accentColor};
                text-shadow: 0 0 10px ${accentColor}44;
            }
            .sa-close {
                background: rgba(255, 255, 255, 0.05);
                border: none;
                color: #64748b;
                cursor: pointer;
                padding: 6px;
                border-radius: 8px;
                transition: all 0.2s;
            }
            .sa-close:hover { background: #1e293b; color: white; transform: rotate(90deg); }
            .sa-content {
                padding: 24px;
                max-height: 500px;
                overflow-y: auto;
            }
            .sa-badge {
                display: inline-flex;
                align-items: center;
                gap: 6px;
                padding: 6px 14px;
                background: ${accentColor};
                color: white;
                border-radius: 99px;
                font-size: 11px;
                font-weight: 800;
                margin-bottom: 16px;
                text-transform: uppercase;
                letter-spacing: 0.08em;
                box-shadow: 0 4px 12px ${accentColor}44;
            }
            .sa-summary {
                font-size: 15px;
                line-height: 1.6;
                color: #f1f5f9;
                margin-bottom: 24px;
                font-weight: 500;
            }
            .sa-section-title {
                font-size: 11px;
                font-weight: 800;
                color: #94a3b8;
                text-transform: uppercase;
                letter-spacing: 0.12em;
                margin-bottom: 16px;
                display: flex;
                align-items: center;
                gap: 8px;
            }
            .sa-finding {
                background: rgba(30, 41, 59, 0.4);
                border: 1px solid #1e293b;
                border-radius: 16px;
                padding: 16px;
                margin-bottom: 12px;
                transition: all 0.2s;
            }
            .sa-finding:hover { border-color: ${accentColor}88; background: rgba(30, 41, 59, 0.6); }
            .sa-finding-title {
                font-size: 14px;
                font-weight: 800;
                color: white;
                margin-bottom: 6px;
            }
            .sa-finding-desc {
                font-size: 13px;
                color: #94a3b8;
                line-height: 1.5;
                margin-bottom: 14px;
            }
            .sa-jump-btn {
                background: ${accentColor}22;
                color: ${accentColor};
                border: 1px solid ${accentColor}44;
                padding: 8px 14px;
                border-radius: 10px;
                font-size: 12px;
                font-weight: 700;
                cursor: pointer;
                display: inline-flex;
                align-items: center;
                gap: 8px;
                transition: all 0.2s;
            }
            .sa-jump-btn:hover { background: ${accentColor}; color: white; transform: translateY(-1px); }
            .sa-footer {
                padding: 20px;
                background: #020617;
                border-top: 1px solid #1e293b;
                font-size: 12px;
                color: #475569;
                text-align: center;
            }
        `;
        shadow.appendChild(style);

        const backdrop = document.createElement('div');
        backdrop.className = 'sa-backdrop';
        shadow.appendChild(backdrop);

        const findings = [];
        if (result.checks) {
            Object.values(result.checks).forEach(check => {
                if (check.flagged) findings.push(check);
            });
        }

        const findingsHtml = findings.map(f => `
            <div class="sa-finding">
                <div class="sa-finding-title">${f.title.replace(/check_|analyze_/g, '').replace(/_/g, ' ').toUpperCase()}</div>
                <div class="sa-finding-desc">${f.details || f.description}</div>
                ${f.matches && f.matches.length > 0 ? `
                    <button class="sa-jump-link sa-jump-btn" data-match="${f.matches[0]}">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><path d="m9 18 6-6-6-6"/></svg>
                        Locate Indicator
                    </button>
                ` : ''}
            </div>
        `).join('');

        const card = document.createElement('div');
        card.className = 'sa-card';
        card.innerHTML = `
            <div class="sa-header">
                <div class="sa-title">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                    SCAM ALERT
                </div>
                <button class="sa-close" id="sa-close">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><path d="M18 6 6 18M6 6l12 12"/></svg>
                </button>
            </div>
            <div class="sa-content">
                <div class="sa-badge">${result.overallSeverity} RISK</div>
                <div class="sa-summary">${result.summary || 'Immediate action recommended. Suspicious patterns detected.'}</div>
                
                <div class="sa-section-title">Critical Findings</div>
                ${findingsHtml || '<div style="color: #64748b; font-size: 13px;">Pattern matches found in email body.</div>'}
                
                <div style="margin-top: 32px;">
                    <div class="sa-section-title">Safety Recommendations</div>
                    <div style="font-size: 13px; color: #94a3b8; background: #1e293b50; padding: 16px; border-radius: 16px; border: 1px dashed #1e293b; line-height: 1.5;">
                        <span style="color: ${accentColor}; font-weight: 700;">•</span> Do not click links or call provided numbers.<br/>
                        <span style="color: ${accentColor}; font-weight: 700;">•</span> Report this as Phishing.<br/>
                        <span style="color: ${accentColor}; font-weight: 700;">•</span> Never provide gift card codes or OTW passwords.
                    </div>
                </div>
            </div>
            <div class="sa-footer">
                Secured by Scam Alert Pro v1.0.38
            </div>
        `;

        shadow.appendChild(card);
        document.body.appendChild(container);

        const close = () => {
            card.style.animation = 'sa-slide-in 0.3s forwards reverse';
            backdrop.style.animation = 'sa-fade-in 0.3s forwards reverse';
            setTimeout(() => container.remove(), 300);
        };

        shadow.getElementById('sa-close').onclick = close;
        backdrop.onclick = close;

        // Jump logic
        shadow.querySelectorAll('.sa-jump-link').forEach(btn => {
            btn.onclick = () => {
                const matchText = btn.getAttribute('data-match');
                const highlights = document.querySelectorAll('.scam-alert-highlight');
                let found = false;
                for (const h of highlights) {
                    if (h.textContent.toLowerCase().includes(matchText.toLowerCase())) {
                        h.scrollIntoView({ behavior: 'smooth', block: 'center' });
                        h.style.outline = `4px solid ${accentColor}`;
                        h.style.outlineOffset = '6px';
                        h.style.borderRadius = '4px';
                        h.style.zIndex = '9999';
                        setTimeout(() => h.style.outline = 'none', 3000);
                        found = true;
                        break;
                    }
                }
                if (!found) console.warn('[Scam Alert] Could not find highlight for:', matchText);
            };
        });
    }

    chrome.runtime.onMessage.addListener((message) => {
        if (message.type === MessageTypes.SCAN_RESULT && message.data?.result) {
            const result = message.data.result;
            console.log('[Scam Alert] Received scan result:', result);

            const isHighRisk = result.overallSeverity === 'CRITICAL' || result.overallSeverity === 'HIGH' || result.overallSeverity === 'MEDIUM';

            if (isHighRisk) {
                console.log('[Scam Alert] Showing alert suite for status:', result.overallSeverity);
                try {
                    // Ensure highlighting is applied before dashboard
                    applyInPageHighlighting(result);
                } catch (e) {
                    console.error('[Scam Alert] Highlighting engine failed:', e);
                }

                try {
                    showThreatDashboard(result);
                } catch (e) {
                    console.error('[Scam Alert] Dashboard engine failed:', e);
                }
            }
        }
    });

    console.log('[Scam Alert] Email scanner active');
})();
