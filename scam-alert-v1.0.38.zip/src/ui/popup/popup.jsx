import React, { useState, useEffect } from 'react';
import ReactDOM from 'react-dom/client';
import { Shield, ShieldAlert, Settings, ExternalLink, Activity } from 'lucide-react';
import { clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';
import '../index.css';

export function cn(...inputs) {
    return twMerge(clsx(inputs));
}

const Popup = () => {
    // ... existing component code ...
    const [status, setStatus] = useState('secure'); // 'secure' | 'warning' | 'scanning'
    const [stats, setStats] = useState({ totalScans: 0, threatsBlocked: 0 });
    const [isPro, setIsPro] = useState(false);
    const [isWhitelisted, setIsWhitelisted] = useState(false);
    const [emailEnabled, setEmailEnabled] = useState(true);
    const [currentUrl, setCurrentUrl] = useState('');

    useEffect(() => {
        // Poll for everything
        const fetchData = () => {
            chrome.storage?.local.get(['statistics', 'settings'], (result) => {
                if (result.statistics) {
                    setStats({
                        totalScans: result.statistics.totalScans || 0,
                        threatsBlocked: result.statistics.threatsBlocked || 0
                    });
                }
                if (result.settings?.planType === 'pro') setIsPro(true);
                if (result.settings?.emailScanningEnabled !== undefined) {
                    setEmailEnabled(result.settings.emailScanningEnabled);
                }
            });

            // Get current tab status
            chrome.runtime.sendMessage({ type: 'GET_TAB_STATUS' }, (response) => {
                if (response?.url) {
                    setCurrentUrl(response.url);
                }
                if (response?.result) {
                    if (response.result.whitelisted) {
                        setIsWhitelisted(true);
                        setStatus('secure');
                    } else if (response.result.overallThreat) {
                        setStatus('warning');
                    } else {
                        setStatus('secure');
                    }
                }
            });
        };

        fetchData();

        // Listener for real-time stats updates
        const listener = (changes, areaName) => {
            if (areaName === 'local' && changes.statistics?.newValue) {
                const newStats = changes.statistics.newValue;
                setStats({
                    totalScans: newStats.totalScans || 0,
                    threatsBlocked: newStats.threatsBlocked || 0
                });
            }
            if (areaName === 'local' && changes.settings?.newValue) {
                const newSettings = changes.settings.newValue;
                if (newSettings.planType === 'pro') setIsPro(true);
                if (newSettings.emailScanningEnabled !== undefined) {
                    setEmailEnabled(newSettings.emailScanningEnabled);
                }
            }
        };

        chrome.storage?.onChanged.addListener(listener);
        return () => chrome.storage?.onChanged.removeListener(listener);
    }, []);

    const handleWhitelist = () => {
        if (!currentUrl) return;
        try {
            const domain = new URL(currentUrl).hostname.replace(/^www\./, '');
            chrome.runtime.sendMessage({
                type: 'ADD_TO_WHITELIST',
                data: { domain }
            }, (response) => {
                if (response?.success) {
                    setIsWhitelisted(true);
                    setStatus('secure');
                }
            });
        } catch (e) {
            console.error('Invalid URL for whitelisting');
        }
    };

    const handleOpenTab = (hash) => {
        const url = chrome.runtime?.getURL ? chrome.runtime.getURL(`options/index.html#${hash}`) : `options/index.html#${hash}`;
        window.open(url);
    };

    const handleToggleEmail = () => {
        const newValue = !emailEnabled;
        setEmailEnabled(newValue);
        chrome.storage?.local.get(['settings'], (result) => {
            const settings = result.settings || {};
            settings.emailScanningEnabled = newValue;
            chrome.storage.local.set({ settings });
        });
    };

    const handleUpgrade = () => {
        chrome.storage?.local.get(['settings'], (result) => {
            const settings = result.settings || {};
            settings.planType = 'pro';
            chrome.storage.local.set({ settings }, () => setIsPro(true));
        });
    };

    return (
        <div className="w-[360px] min-h-[400px] bg-slate-900 text-white font-sans antialiased selection:bg-indigo-500 selection:text-white overflow-hidden">
            {/* Header / Status Card */}
            <div className={cn(
                "relative p-6 pt-8 pb-12 rounded-b-[2.5rem] shadow-2xl transition-all duration-500 ease-out",
                status === 'secure' ? "bg-gradient-to-br from-indigo-600 to-violet-700" : "bg-gradient-to-br from-rose-600 to-orange-600"
            )}>
                {/* Abstract Background Shapes */}
                <div className="absolute top-0 left-0 w-full h-full overflow-hidden opacity-20 pointer-events-none">
                    <div className="absolute -top-12 -right-12 w-48 h-48 bg-white rounded-full blur-3xl"></div>
                    <div className="absolute bottom-0 left-0 w-32 h-32 bg-black rounded-full blur-2xl"></div>
                </div>

                <div className="relative z-10 flex flex-col items-center text-center">
                    <div className={cn(
                        "p-4 rounded-full bg-white/10 backdrop-blur-md border border-white/20 shadow-inner mb-4 animate-in fade-in zoom-in duration-300",
                        status === 'secure' ? "text-emerald-300" : "text-rose-200 shadow-[0_0_20px_rgba(225,29,72,0.4)] animate-pulse"
                    )}>
                        {status === 'secure' ? <Shield size={48} strokeWidth={1.5} /> : <ShieldAlert size={48} strokeWidth={1.5} />}
                    </div>
                    <div className="flex items-center gap-2">
                        <h1 className="text-2xl font-bold tracking-tight">
                            {status === 'secure' ? 'No Threats Detected' : 'Threat Detected'}
                        </h1>
                        {isPro && (
                            <span className="bg-white/20 backdrop-blur-md px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-widest border border-white/30">PRO</span>
                        )}
                    </div>
                    <p className="text-white/70 text-sm font-medium">
                        {status === 'secure' ? 'No phishing or scams found' : 'Suspicious activity blocked'}
                    </p>
                </div>
            </div>

            {/* Main Content */}
            <div className="px-5 -mt-8 relative z-20">

                {/* Email Protection Toggle */}
                <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700/50 rounded-2xl mb-5 overflow-hidden">
                    <div className="flex items-center justify-between p-4">
                        <div
                            onClick={() => handleOpenTab('dashboard')}
                            className="flex items-center gap-3 cursor-pointer group hover:opacity-80 transition-all"
                        >
                            <div className={cn(
                                "p-2 rounded-lg",
                                emailEnabled ? "bg-emerald-500/10 text-emerald-400" : "bg-slate-700 text-slate-500"
                            )}>
                                <Shield size={20} />
                            </div>
                            <div className="text-left">
                                <div className="text-sm font-semibold text-slate-200 flex items-center gap-1.5">
                                    Email Protection
                                    <ExternalLink size={12} className="opacity-0 group-hover:opacity-100 transition-opacity" />
                                </div>
                                <div className="text-xs text-slate-500">{emailEnabled ? 'Scanning Gmail & Outlook' : 'Protection Disabled'}</div>
                            </div>
                        </div>
                        <button
                            onClick={handleToggleEmail}
                            className={cn(
                                "w-12 h-6 rounded-full transition-colors relative",
                                emailEnabled ? "bg-indigo-600" : "bg-slate-700"
                            )}>
                            <div className={cn(
                                "absolute top-1 w-4 h-4 bg-white rounded-full transition-all",
                                emailEnabled ? "left-7" : "left-1"
                            )} />
                        </button>
                    </div>
                </div>

                <div className="grid grid-cols-2 gap-3 mb-5">
                    <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700/50 p-4 rounded-2xl flex flex-col items-center justify-center hover:bg-slate-800 transition-colors">
                        <span className="text-slate-400 text-xs font-semibold uppercase tracking-wider mb-1">Pages Scanned</span>
                        <span className="text-2xl font-bold text-white">{stats.totalScans.toLocaleString()}</span>
                    </div>
                    <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700/50 p-4 rounded-2xl flex flex-col items-center justify-center hover:bg-slate-800 transition-colors">
                        <span className="text-slate-400 text-xs font-semibold uppercase tracking-wider mb-1">Blocked</span>
                        <span className="text-2xl font-bold text-rose-400">{stats.threatsBlocked.toLocaleString()}</span>
                    </div>
                </div>

                {/* Quick Actions */}
                <div className="space-y-3">
                    <button
                        onClick={() => handleOpenTab('logs')}
                        className="w-full group relative flex items-center justify-between p-4 bg-slate-800 hover:bg-slate-700 border border-slate-700 hover:border-indigo-500/50 rounded-xl transition-all duration-200"
                    >
                        <div className="flex items-center gap-3">
                            <div className="p-2 bg-indigo-500/10 rounded-lg text-indigo-400 group-hover:text-indigo-300 transition-colors">
                                <Activity size={20} />
                            </div>
                            <div className="text-left">
                                <div className="text-sm font-semibold text-slate-200">View Activity Log</div>
                                <div className="text-xs text-slate-500">Recent scans & threats</div>
                            </div>
                        </div>
                        <ExternalLink size={16} className="text-slate-500 group-hover:text-white transition-colors" />
                    </button>

                    <button
                        onClick={() => handleOpenTab('settings')}
                        className="w-full group relative flex items-center justify-between p-4 bg-slate-800 hover:bg-slate-700 border border-slate-700 hover:border-indigo-500/50 rounded-xl transition-all duration-200"
                    >
                        <div className="flex items-center gap-3">
                            <div className="p-2 bg-slate-700/50 rounded-lg text-slate-400 group-hover:text-white transition-colors">
                                <Settings size={20} />
                            </div>
                            <div className="text-left">
                                <div className="text-sm font-semibold text-slate-200">Settings</div>
                                <div className="text-xs text-slate-500">Manage protection levels</div>
                            </div>
                        </div>
                    </button>

                    {status !== 'secure' && !isWhitelisted && (
                        <button
                            onClick={handleWhitelist}
                            className="w-full group relative flex items-center justify-between p-4 bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/20 hover:border-emerald-500/40 rounded-xl transition-all duration-200"
                        >
                            <div className="flex items-center gap-3">
                                <div className="p-2 bg-emerald-500/20 rounded-lg text-emerald-400">
                                    <Shield size={20} />
                                </div>
                                <div className="text-left">
                                    <div className="text-sm font-semibold text-emerald-200">Always Trust this Site</div>
                                    <div className="text-xs text-emerald-500/70">Add to whitelist</div>
                                </div>
                            </div>
                        </button>
                    )}

                    {isWhitelisted && (
                        <div className="w-full flex items-center justify-center p-3 bg-emerald-500/5 border border-emerald-500/10 rounded-xl">
                            <span className="text-xs font-bold text-emerald-500 uppercase tracking-widest flex items-center gap-2">
                                <Shield size={14} /> Whitelisted Domain
                            </span>
                        </div>
                    )}

                    {!isPro && (
                        <button
                            onClick={handleUpgrade}
                            className="w-full relative overflow-hidden p-4 bg-gradient-to-r from-amber-500/10 to-orange-500/10 border border-amber-500/20 rounded-xl group hover:border-amber-500/40 transition-all"
                        >
                            <div className="flex items-center gap-3">
                                <div className="p-2 bg-amber-500/20 rounded-lg text-amber-500">
                                    <Shield size={20} />
                                </div>
                                <div className="text-left">
                                    <div className="text-sm font-bold text-amber-200">Unlock Pro Protection</div>
                                    <div className="text-xs text-amber-500/70">Advanced heuristics & Live Map</div>
                                </div>
                            </div>
                        </button>
                    )}
                </div>

            </div>

            {/* Footer */}
            <div className="mt-6 text-center pb-6">
                <p className="text-xs text-slate-600 font-medium">Scam Alert Pro v1.0.38</p>
            </div>

        </div>
    );
};

ReactDOM.createRoot(document.getElementById('root')).render(
    <React.StrictMode>
        <Popup />
    </React.StrictMode>
);
